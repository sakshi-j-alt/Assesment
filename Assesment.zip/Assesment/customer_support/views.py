# customer_support/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from customer_requests.models import ServiceRequest
from ..customer_supports.forms import ManageRequestForm

# Restrict access to customer support representatives (you can customize this check)
def is_support_rep(user):
    return user.groups.filter(name='Support').exists() or user.is_superuser

@user_passes_test(is_support_rep)
def support_dashboard(request):
    # Display all service requests (you can filter by pending or resolved here if needed)
    requests = ServiceRequest.objects.all()
    return render(request, 'support_dashboard.html', {'requests': requests})

@user_passes_test(is_support_rep)
def manage_request(request, request_id):
    # Get the service request to be updated
    service_request = get_object_or_404(ServiceRequest, id=request_id)
    if request.method == 'POST':
        form = ManageRequestForm(request.POST, instance=service_request)
        if form.is_valid():
            form.save()
            return redirect('support_dashboard')
    else:
        form = ManageRequestForm(instance=service_request)
    return render(request, 'request_manage.html', {'form': form, 'service_request': service_request})
