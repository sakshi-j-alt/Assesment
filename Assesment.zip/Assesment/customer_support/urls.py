# customer_support/urls.py
from django.urls import path
from customer_supports import views

urlpatterns = [
    path('dashboard/', views.support_dashboard, name='support_dashboard'),
    path('requests/<int:request_id>/manage/', views.manage_request, name='manage_request'),
]
