# customer_requests/urls.py
from django.urls import path
from customer_requests import views

urlpatterns = [
    path('submit/', views.create_service_request, name='create_request'),
    path('requests/', views.view_service_requests, name='request_list'),
    path('requests/<int:request_id>/', views.request_detail, name='request_detail'),
]
