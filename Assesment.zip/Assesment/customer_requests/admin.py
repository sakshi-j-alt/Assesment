# customer_requests/admin.py
from django.contrib import admin
from .models import ServiceRequest

class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'request_type', 'status', 'created_at', 'updated_at')
    list_filter = ('status',)
    search_fields = ('request_type', 'description')

admin.site.register(ServiceRequest, ServiceRequestAdmin)
